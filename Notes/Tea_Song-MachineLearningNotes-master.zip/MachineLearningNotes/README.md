# MachineLearningNotes
## Reference

1.  https://www.bilibili.com/video/av70839977?from=search&seid=17463814830541838470 
2.  [**P**attern **R**ecognition and **M**achine **L**earning](https://www.*microsoft*.com/en-us/research/uploads/prod/2006/01/Bishop-Pattern-Recognition-and-Machine-Learning-2006.pdf )

GitHub 本身不支持公式，因此请下载到本地使用 [Typora](https://www.typora.io/)观看。

Update:

为了更好的效果，我将所有文档放在[语雀文档](https://www.yuque.com/books/share/f4031f65-70c1-4909-ba01-c47c31398466?#)里面了，欢迎大家评论。

The notes are from videos mostly.

The markdown files are written with typora. The graphs and equations cannot be rendered properly due the lack of Mathjax/Mermaid support in GitHub.



I do not know how to draw the PGM properly in markdown and here Mermaid is used.

